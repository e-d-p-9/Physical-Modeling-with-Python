Geographic locations of a set of incidents.

Map data of incidents from http://bombsight.org/#14/51.4465/-0.0756
Some points are duplicated because the map indicated multiple unresolved hits at that point.

File londonIncidents.npz contains:
 - variable all = array of (x,y) pairs describing map coordinates, of each incident in
	  arbitrary units
 - variable allrefs = array of four (x,y) pairs describing reference points. In real space, in 2019, those points are:
  upper left: intersection of Grosvenor Pl and Duke of Wellington Pl
  lower left: intersection of Chelsea Bridge Rd and Ebury Br Rd
  upper right: intersection of Tooley St and Tower Bridge Rd
  lower right: intersection of Old Kent Rd and Trafalgar Ave
 
Files londonIncidentsAll.npy and londonIncidentsAllrefs.npy contain the same data in npy format.
colquhounData.npy contains an array:

Column 2 contains the integer numbers of channels that closed during a 0.5ms time window starting at the value in column 1 (in ms). (The first bin was unreliable and is not included.)

Data from Colquhoun and Hawkes, "Principles of the stochastic interpretation of ion-channel mechanisms" in  "Single channel recording" 1995 ed. B Sakmann and E Neher.  Caption says "(R. temporaria , synaptic channels, 50 nM acetylcholine,
 -80 mV, 8 degC. DC Ogden, DJ Adams, and D Colquhoun unpublished data.)"

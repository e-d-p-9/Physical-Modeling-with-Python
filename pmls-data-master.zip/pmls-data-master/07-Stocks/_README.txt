Files djiweekly2020.npz and djiweekly2020.txt variable djiweekly with closing values of the Dow Jones Industrial Average on 4223 consecutive weeks  from 1921 to 2020.

Files djiweekly.csv and djiweekly.npy contain the same data in column 1.

File Visscher.npz contains three arrays:
velocityVsATP: Selected points from Fig 2 of the paper. First Column: ATP concentration, micromolar. Second Column 2: Kinesin velocities, micrometer/s.

forces: Retarding force for each data point, pN

velocityVsForce: Selected points from Fig 3A of the paper, all with [ATP]=5 micromolar. First Column: Retarding force, pN. Second Column: Kinesin velocities, micrometer/s.

Data from K Visscher et al. DOI: 10.1038/22146


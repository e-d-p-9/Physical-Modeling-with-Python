File g112APDtraces.csv and g112APDtraces.npy contains columns of data:
	- Columns 1--2 correspond to higher illumination;
	- Columns 3--4 are medium illumination;
	- Columns 5--6 are for the lowest illumination.

In each pair of columns, the first entry is time in seconds;
the second is detector output in volts at that time.

Data courtesy John Beausang.

Measles outbreak data (Netherlands, 2000).

File SIAMRev.Hethcote.txt: First column, time [days]. Second column, number of cases.

[Data from van Steenbergen, J. E., van den Hof, S., Langendam, M. W., van de Kerkhof, J. H. T. C., & Ruijs, W. L. M. (2000). Measles Outbreak---Netherlands, April 1999--January 2000. Morbidity and Mortality Weekly Report, 49(14), 299–303.]

Novick/Weiner data for protein folding.

g149novickA.mat is data from their Fig. 1 (high inducer).
	Column 1:	Time in hours. The e-folding time was about 3 hours.
	Column 2:	Fraction of maximum beta-galactosidase activity.

g149novickB.mat is data from their Fig. 2 (low inducer).
	Column 1:	Time in hours. The e-folding time was about 3 hours.
	Column 2:	Fraction of maximum beta-galactosidase activity.

g149novickA.txt, g149novickA.npy, g149novickB.txt, and g149novickB.npy contain
the same data.

novick.npz:
	Both data sets in a single file.

Novick and Weiner. Enzyme induction as an all-or-none phenomenon.
Proc Natl Acad Sci USA (1957) vol. 43 (7) pp. 553--66.

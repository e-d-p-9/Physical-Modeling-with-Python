Novick/Weiner data.
[Data from Novick and Weiner. Enzyme induction as an all-or-none phenomenon.
Proc Natl Acad Sci USA (1957) vol. 43 (7) pp. 553--66.]

g149novickA.txt is data from their Fig. 1 (high inducer level).
	Column 1:	Time in hours. (Their graph gave t/tau, where the e-folding time tau was about 3 hours (Novick/Weiner page 555).)
	Column 2:	Fraction of maximum beta-galactosidase activity.

g149novickB.txt is data from their Fig. 4 (moderate inducer).
	Column 1:	Time in hours. The e-folding time was about 3 hours.
	Column 2:	Fraction of maximum beta-galactosidase activity.

File 20-08-03time-series-covid19-confirmed-US.csv : Data accessed 3 August 2020 from
https://github.com/CSSEGISandData/COVID-19
Data in folder:  https://github.com/CSSEGISandData/COVID-19/tree/master/csse_covid_19_data/csse_covid_19_time_series
File: time_series_covid19_confirmed_US.csv
Description:  https://github.com/CSSEGISandData/COVID-19/blob/master/csse_covid_19_data/csse_covid_19_time_series/README.md
says "Time series table for the US confirmed cases, reported at the county level."
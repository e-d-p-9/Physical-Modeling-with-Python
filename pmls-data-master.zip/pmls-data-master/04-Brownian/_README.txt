Jean Perrin's data on Brownian motion. Files g26perrindata.mat , g26perrindata.txt, g26perrindata.csv, g26perrindata.npy [data from J Perrin, Les Atomes]. 

The columns give x, y coordinates of 508 points in in micrometers. Each such point in turn is the net displacement of a colloidal particle of radius 0.37 nm over 30 s of Brownian motion.
